﻿Project information  

Based on the AddNew code example.  
Adds Edit and Delete tasks.

For a single entity that's NOT associated with another entity, this code example shows you the *best practice* approach for these use cases:
- Get all
- Get one
- Add new
- Edit existing
- Delete item
