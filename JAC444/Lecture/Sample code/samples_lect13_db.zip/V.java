
//definitions for constant values in DB
//this is a quick solution is NOT recommended
public class V {
    public static final String DRIVER_CLASS_MYSQL
            = "com.mysql.jdbc.Driver";

    public static final String URL
            = "jdbc:mysql://localhost:3306/firstDB";

    public static final String U
            = "root";

    public static final String P
            = "root";
}
