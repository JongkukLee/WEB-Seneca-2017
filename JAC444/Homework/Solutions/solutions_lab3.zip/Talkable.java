package test;

public interface Talkable {
    void say();
}
